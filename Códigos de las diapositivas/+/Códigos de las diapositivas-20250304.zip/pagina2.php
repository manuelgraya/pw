<?php 
echo 'Pagina 2 - Hola ',$nombre??'';  
?> 