<?php 
$una_variable = 10; 
$nombre_variable = 'una_variable'; 
echo '$una_variable = ',$una_variable,'<br />'; 
echo '$nombre_variable = ',$nombre_variable,'<br />'; 
echo '$$nombre_variable = ',$$nombre_variable,'<br />'; 
?> 