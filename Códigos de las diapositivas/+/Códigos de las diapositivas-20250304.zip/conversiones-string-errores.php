<?php   
echo '1 + "1abc" = ',(1 + "1abc"),'<br />';  
echo '1 + "1.5abc" = ',(1 + "1.5abc"),'<br />';  
echo '1 + "  1.5 abc" = ',(1 + "  1.5 abc"),'<br />';  
echo '1 + "abc1" = ',(1 + "abc1"),'<br />';  
?> 