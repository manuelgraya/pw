<?php 
$_nombre = $_GET['nombre'];
echo "Pagina 2 - Hola $_nombre"; 
?> 