<?php 
// Definir una constante. 
define('NOMBRE','UCA'); 
?> 
<html> 
<body> 
<p>¡Hola <b><?= NOMBRE; ?>!</p> 
</body> 
</html> 