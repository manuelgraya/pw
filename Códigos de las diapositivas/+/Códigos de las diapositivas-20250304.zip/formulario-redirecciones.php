<!DOCTYPE html> 
<html xmlns="http://www.w3.org/1999/xhtml" lang="es"> 
  <head> 
    <meta charset="utf-8" /> 
    <title>Entrada de datos</title> 
  </head> 
  <body> 
    <form action="proceso-redirecciones.php" method="post"> 
    <div> 
      Nombre: 
      <input type="text" name="nombre" value="" /> 
      <input type="submit" name="aceptar" value="Aceptar" /> 
    </div> 
    </form> 
  </body> 
</html> 

