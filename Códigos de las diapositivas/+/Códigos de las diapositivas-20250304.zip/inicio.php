<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="es">
  <head>
    <meta charset="utf-8" />
    <title>PW 2024</title>
  </head>
  <body>
    <div>
    Bienvenidos a Programación Web
    </div>
  </body>
</html>
