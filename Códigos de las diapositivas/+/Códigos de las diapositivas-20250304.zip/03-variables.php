<?php 
// Mostrar el contenido de la variable $nombre. 
echo '$nombre = ',$nombre,'<br />'; 
// Inicializar la variable $nombre. 
$nombre = 'Olivier'; 
// Mostrar de nuevo el contenido de la variable $nombre. 
echo '$nombre = ',$nombre,'<br />'; 
?> 