<?php 
// Visualización de los datos contenidos 
// en las tablas $_POST y $_REQUEST. 
echo '$_POST[\'nombre\'] -> ',$_POST['nombre'] ,'<br />'; 
echo '$_REQUEST[\'nombre\'] -> ',$_REQUEST['nombre'] ,'<br />'; 
?> 