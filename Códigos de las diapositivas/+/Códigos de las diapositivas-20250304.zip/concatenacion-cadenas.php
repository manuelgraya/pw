<?php 
// Utilización del operador de concatenación 
// con variables y expresiones literales. 
$nombre = 'Olivier'; 
$apellido = 'Heurtel'; 
echo $apellido.', '.$nombre.'<br />'; 
?> 