<?php 
$nombre = 'Torcuato'; 
echo $nombre[0],$nombre[5],$nombre[-2]; 
?> 