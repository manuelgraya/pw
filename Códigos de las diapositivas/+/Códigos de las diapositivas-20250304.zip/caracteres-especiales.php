<?php 
echo "Hola \104\141\156\151\145\154. <br />"; 
echo "\u{1F600}\n";
echo "\u{1F601}\n";
?> 